// Program For do..while loop

#include <stdio.h>

int main()
{
    int i = 0;
    do {
        printf("Geeks\n");
        i++;
        }
    while (i < 3);

    return 0;
}
